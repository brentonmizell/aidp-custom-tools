"""Credential Store auth — reference implementation for custom code tools.

JR-Sambit thread (Jun 2026) — when a custom tool must call the public AIDP /
OCI APIs from inside AIDP, the working production path is *not* the resource-
principal signer and *not* a hardcoded PEM in the zip. It is:

    1. Operator creates a SECRET_TOKEN credential in AIDP's Credential Store
       containing four secret-key pairs: tenancy / user / fingerprint /
       private_key  (the PEM body, not a path).
    2. The tool config carries the credential's display name as a regular
       (non-secret) parameter — the secret value never leaves the store.
    3. At runtime, the tool calls `aidputils.secrets.get(name, key)` for each
       field and constructs an `oci.signer.Signer(private_key_content=...)`.

This sample exposes two operations against the same volumes endpoint that
returned 401 under resource principal — confirming the credential-store
signer succeeds where rp signing fails.

Required SECRET_TOKEN keys
--------------------------
The credential MUST have these four secret-key entries; the SDK normalizes
them via _normalize_secret_token in CredentialStoreService:

    tenancy       ocid1.tenancy.oc1..…
    user          ocid1.user.oc1..…
    fingerprint   aa:bb:cc:dd:…
    private_key   -----BEGIN RSA PRIVATE KEY-----\\n…\\n-----END RSA PRIVATE KEY-----\\n
"""

from __future__ import annotations

import json
from typing import Any, Dict, Optional

import requests

from aidputils.agents.tools.custom_tools.base import CustomToolBase

from .utils.config_utils import get_cfg, ok, fail

try:
    from aidp_debug import debug, debug_warn, debug_error, DebugLog
except ImportError:
    def debug(*a, **k): pass
    def debug_warn(*a, **k): pass
    def debug_error(*a, **k): pass
    class DebugLog:
        @staticmethod
        def embed(r): return r


REQUIRED_SECRET_KEYS = ("tenancy", "user", "fingerprint", "private_key")


def _mask(value: Optional[str], keep: int = 4) -> str:
    """Truncate a secret for debug output. Never log full tokens / keys."""
    if not value:
        return "<empty>"
    if len(value) <= keep * 2:
        return f"<{len(value)} chars>"
    return f"{value[:keep]}…{value[-keep:]}  ({len(value)} chars)"


def _build_signer(credential_name: str) -> tuple:
    """Resolve the credential by display name and return (signer, redacted_meta).
    Returns (None, error_msg) if anything is missing."""
    try:
        import aidputils.secrets as secrets
    except ImportError as ex:
        return None, f"aidputils.secrets not available: {ex}"

    try:
        # One bulk fetch + key validation gives a better error than four
        # silent get(name, key) calls if the credential is misconfigured.
        bundle = secrets.get(credential_name)
    except Exception as ex:
        return None, f"Credential `{credential_name}` could not be read: {ex}"

    if not isinstance(bundle, dict):
        return None, (f"Credential `{credential_name}` did not return a dict "
                      f"(got {type(bundle).__name__}). The credential must be "
                      f"SECRET_TOKEN type, not SERVICE_ACCOUNT or VAULT_REFERENCE.")

    missing = [k for k in REQUIRED_SECRET_KEYS if not bundle.get(k)]
    if missing:
        return None, (f"Credential `{credential_name}` is missing secret keys: "
                      f"{missing}. Required: {list(REQUIRED_SECRET_KEYS)}.")

    import re
    # Normalize: secret stores / paste forms on Windows add \r\n + stray
    # whitespace. A stray char in the fingerprint or OCIDs corrupts the signed
    # keyId header and produces an opaque 401 NotAuthenticated.
    tenancy = str(bundle["tenancy"]).strip()
    user = str(bundle["user"]).strip()
    fingerprint = "".join(str(bundle["fingerprint"]).split())
    private_key = (str(bundle["private_key"]).replace("\r\n", "\n")
                   .replace("\r", "\n").strip() + "\n")

    if not re.fullmatch(r"[0-9a-fA-F]{2}(:[0-9a-fA-F]{2}){15}", fingerprint):
        return None, (
            f"fingerprint doesn't look like a valid OCI API-key fingerprint "
            f"(got {len(fingerprint)} chars; expected 47 in the form "
            f"aa:bb:…:zz). Copy it exactly from OCI Console → your user → "
            f"API Keys, or derive it: openssl rsa -pubout -outform DER -in "
            f"key.pem | openssl md5 -c")

    import oci
    # private_key_file_location is a required positional arg in some OCI SDK
    # builds (e.g. 2.175.x preview) even when signing from private_key_content.
    signer = oci.signer.Signer(
        tenancy=tenancy,
        user=user,
        fingerprint=fingerprint,
        private_key_file_location=None,
        private_key_content=private_key,
    )
    redacted = {
        "tenancy":     _mask(tenancy, 6),
        "user":        _mask(user, 6),
        "fingerprint": _mask(fingerprint, 2),
        "fingerprint_len": len(fingerprint),
        "private_key": _mask(private_key, 12),
    }
    return signer, redacted


@CustomToolBase.register
class CredentialStoreAuthSample(CustomToolBase):
    """Demonstrates calling public AIDP APIs with a credential-store-backed
    OCI signer. Two operations:

        op="whoami"        — calls GET /20240501/users/{userId} on identity
                             to confirm the signer is valid end-to-end.
        op="list_volumes"  — calls GET /20260430/aiDataPlatforms/{lakeOcid}/
                             catalogs/{catalogKey}/schemas/{schemaKey}/volumes
                             with the credential-store signer (the call that
                             returned 401 under resource principal).
    """

    @classmethod
    def _execute_tool(cls, conf: Dict[str, Any], runtime_params: Dict[str, Any],
                      **context_vars) -> Dict[str, Any]:
        op = (runtime_params.get("op") or "whoami").lower()
        credential_name = (runtime_params.get("credential_name")
                           or get_cfg(conf, "credential_name", ""))
        timeout = get_cfg(conf, "timeout", 30)
        region = get_cfg(conf, "region", "us-ashburn-1")

        debug(f"CredentialStoreAuthSample op={op} credential_name={credential_name!r}")

        if not credential_name:
            return DebugLog.embed(fail(
                "credential_name is required — pass it as a runtime param or "
                "set conf.credential_name.", "ValidationError"))

        signer, meta = _build_signer(credential_name)
        if signer is None:
            return DebugLog.embed(fail(meta, "CredentialStoreError"))
        debug(f"Signer constructed. Redacted credential meta: {meta}")

        try:
            if op == "whoami":
                return DebugLog.embed(cls._do_whoami(signer, meta, region, timeout))
            if op in ("list_catalogs", "list_schemas", "list_tables",
                      "list_volumes", "list_kbs"):
                return DebugLog.embed(cls._do_list(
                    op, signer, meta, conf, runtime_params, region, timeout))
            if op == "list_files":
                return DebugLog.embed(cls._do_list_files(
                    signer, meta, conf, runtime_params, region, timeout))
            if op in ("get_kb", "get_volume"):
                return DebugLog.embed(cls._do_get_by_key(
                    op, signer, meta, conf, runtime_params, region, timeout))
            return DebugLog.embed(fail(
                f"Unknown op `{op}`. Valid: whoami | list_catalogs | "
                f"list_schemas | list_tables | list_volumes | list_kbs | "
                f"list_files | get_kb | get_volume.", "ValidationError"))
        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else "?"
            body = e.response.text[:500] if e.response is not None else ""
            # Distinguish "signature rejected" from "authenticated but not
            # authorized for THIS resource". 401 = bad credential; 404
            # NotAuthorizedOrNotFound on whoami = the signer authenticated but
            # the user lacks `read users` IAM permission — expected for a
            # locked-down service user. That is NOT a credential failure.
            if op == "whoami" and status == 404 and "NotAuthorizedOrNotFound" in body:
                return DebugLog.embed(ok({
                    "operation": "whoami",
                    "authenticated": True,
                    "note": ("Signer AUTHENTICATED successfully (a bad "
                             "credential returns 401, not 404). This 404 means "
                             "the user lacks `read users` IAM permission to "
                             "read its own record — expected for a service "
                             "user, and not needed for AIDP calls. Run "
                             "op=list_volumes to test the actual data-plane "
                             "call."),
                    "redacted_credential": meta,
                }))
            if op == "whoami" and status == 401:
                return DebugLog.embed(fail(
                    "Signer was REJECTED (HTTP 401 NotAuthenticated). The "
                    "credential is wrong: verify the fingerprint matches the "
                    "private key (openssl rsa -pubout -outform DER -in key.pem "
                    "| openssl md5 -c) and that this API key is still active "
                    "for the user in OCI Console.", "HTTPError",
                    redacted_credential=meta))
            return DebugLog.embed(fail(
                f"HTTP {status} from {e.request.url}: {body}", "HTTPError",
                redacted_credential=meta))
        except Exception as e:
            return DebugLog.embed(fail(str(e), type(e).__name__,
                                       redacted_credential=meta))

    @classmethod
    def _do_whoami(cls, signer, meta, region, timeout):
        # Identity endpoint — confirms the API key / signer combination is
        # valid before chasing data-plane 401s.
        user_id = meta["user"]  # masked; rebuild from signer instead
        user_id = signer.api_key.split("/")[1]  # "<tenancy>/<user>/<fp>"
        url = f"https://identity.{region}.oci.oraclecloud.com/20160918/users/{user_id}"
        r = requests.get(url, auth=signer, timeout=timeout)
        r.raise_for_status()
        body = r.json()
        return ok({
            "operation": "whoami",
            "user": {
                "name": body.get("name"),
                "id": body.get("id"),
                "tenancy_id": body.get("compartmentId"),
                "lifecycle_state": body.get("lifecycleState"),
            },
            "redacted_credential": meta,
        })

    @classmethod
    def _do_list(cls, op, signer, meta, conf, runtime_params, region, timeout):
        """Discovery + test chain against the AIDP data plane. The real AIDP
        API uses FLAT resources with query params (not nested path segments):

            list_catalogs  GET /catalogs                              (lake)
            list_schemas   GET /schemas?catalogKey=..                 (+catalog_key)
            list_tables    GET /tables?catalogKey=..&schemaKey=..     (+schema_key)
            list_volumes   GET /volumes?catalogKey=..&schemaKey=..    (+schema_key)
            list_kbs       GET /knowledgeBases?catalogKey=..&schemaKey=..

        Run them in order to discover the keys the next op needs. Keys are
        opaque strings whose format varies by resource type — a catalog key
        may be a hex id, a schema key is often catalog.schema, a KB key is a
        hex id. Never guess; copy the `key` field from the prior op's output.

        .strip() every value: a leading/trailing space pasted into the Test
        panel becomes %20 in the query and yields a spurious 404.
        """
        from urllib.parse import quote

        lake = (runtime_params.get("data_lake_ocid")
                or get_cfg(conf, "data_lake_ocid", "")).strip()
        catalog = (runtime_params.get("catalog_key")
                   or get_cfg(conf, "catalog_key", "")).strip()
        schema = (runtime_params.get("schema_key")
                  or get_cfg(conf, "schema_key", "")).strip()

        _needs_all = [("data_lake_ocid", lake), ("catalog_key", catalog),
                      ("schema_key", schema)]
        required = {"list_catalogs": [("data_lake_ocid", lake)],
                    "list_schemas":  [("data_lake_ocid", lake),
                                      ("catalog_key", catalog)],
                    "list_tables":   _needs_all,
                    "list_volumes":  _needs_all,
                    "list_kbs":      _needs_all}[op]
        for name, val in required:
            if not val:
                return fail(f"{name} is required for {op}.", "ValidationError")

        api_version = str(get_cfg(conf, "api_version", "20260430")).strip()
        service_path = str(get_cfg(conf, "service_path", "aiDataPlatforms")).strip()
        base = (f"https://aidp.{region.strip()}.oci.oraclecloud.com/"
                f"{api_version}/{service_path}/{lake}")
        cat_q = quote(catalog, safe="")
        sch_q = quote(schema, safe="")
        path = {
            "list_catalogs": "/catalogs",
            "list_schemas":  f"/schemas?catalogKey={cat_q}",
            "list_tables":   f"/tables?catalogKey={cat_q}&schemaKey={sch_q}",
            "list_volumes":  f"/volumes?catalogKey={cat_q}&schemaKey={sch_q}",
            "list_kbs":      f"/knowledgeBases?catalogKey={cat_q}&schemaKey={sch_q}",
        }[op]
        url = base + path
        debug(f"GET {url}")

        try:
            r = requests.get(url, auth=signer, timeout=timeout,
                             headers={"Accept": "application/json"})
            r.raise_for_status()
        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else "?"
            body = e.response.text[:300] if e.response is not None else ""
            hint = ""
            if status == 404:
                hint = (" — 404 means the resource wasn't found. Confirm each "
                        "value is the exact `key` from the prior op's output "
                        "(run op=list_catalogs, then op=list_schemas) — not a "
                        "display name, and with no stray spaces.")
            return fail(f"HTTP {status} from {url}: {body}{hint}", "HTTPError",
                        redacted_credential=meta)

        body = r.json()
        items = body.get("items", body if isinstance(body, list) else [])
        return ok({
            "operation": op,
            "url": url,
            "count": len(items),
            "items": [
                {"key": it.get("key"),
                 "displayName": it.get("displayName"),
                 "type": it.get("catalogType") or it.get("type"),
                 "lifecycleState": it.get("lifecycleState")}
                for it in items
            ],
            "next": {
                "list_catalogs": "copy a catalog `key` into catalog_key, then "
                                 "run op=list_schemas",
                "list_schemas":  "copy a schema `key` into schema_key, then run "
                                 "op=list_tables / list_volumes / list_kbs",
                "list_tables":   "done — these are your tables",
                "list_volumes":  "copy a volume `key` into volume_key, then "
                                 "run op=list_files to browse its contents",
                "list_kbs":      "done — these are your knowledge bases",
            }[op],
            "note": ("count=0 means the call succeeded but nothing matched this "
                     "catalog_key + schema_key pair. Re-run op=list_catalogs and "
                     "op=list_schemas and use the EXACT `key` values they return "
                     "— a hand-typed or mismatched key returns an empty list, "
                     "not an error." if not items else ""),
            "redacted_credential": meta,
        })

    @classmethod
    def _do_list_files(cls, signer, meta, conf, runtime_params, region, timeout):
        """List files/folders inside a volume — the level below list_volumes.

            GET /volumes/{volumeKey}/files?path=/

        The volume key is the full dotted path catalog.schema.volume, e.g.
        construction_catalog.construction_schema.construction_documents.
        `path` defaults to '/' (the volume root); pass a subfolder to descend.
        """
        from urllib.parse import quote

        volume_key = (runtime_params.get("volume_key")
                      or get_cfg(conf, "volume_key", "")).strip()
        path = (runtime_params.get("path") or "/").strip() or "/"
        if not volume_key:
            return fail("volume_key is required for list_files (the full "
                        "catalog.schema.volume key from op=list_volumes).",
                        "ValidationError")

        lake = (runtime_params.get("data_lake_ocid")
                or get_cfg(conf, "data_lake_ocid", "")).strip()
        api_version = str(get_cfg(conf, "api_version", "20260430")).strip()
        service_path = str(get_cfg(conf, "service_path", "aiDataPlatforms")).strip()
        url = (f"https://aidp.{region.strip()}.oci.oraclecloud.com/"
               f"{api_version}/{service_path}/{lake}/volumes/"
               f"{quote(volume_key, safe='')}/files?path={quote(path, safe='')}")
        debug(f"GET {url}")

        try:
            r = requests.get(url, auth=signer, timeout=timeout,
                             headers={"Accept": "application/json"})
            r.raise_for_status()
        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else "?"
            body = e.response.text[:300] if e.response is not None else ""
            hint = (" — confirm volume_key is the exact `key` from "
                    "op=list_volumes (catalog.schema.volume).") if status == 404 else ""
            return fail(f"HTTP {status} from {url}: {body}{hint}", "HTTPError",
                        redacted_credential=meta)

        body = r.json()
        items = body.get("items", body if isinstance(body, list) else [])
        return ok({
            "operation": "list_files",
            "url": url,
            "volume_key": volume_key,
            "path": path,
            "count": len(items),
            "items": [
                {"name": it.get("name") or it.get("displayName"),
                 "path": it.get("path"),
                 "type": (it.get("type") or it.get("objectType") or "file")}
                for it in items
            ],
            "redacted_credential": meta,
        })

    @classmethod
    def _do_get_by_key(cls, op, signer, meta, conf, runtime_params, region, timeout):
        """Fetch one resource DIRECTLY by its own key — no catalogKey/schemaKey
        filter. This is the pattern that works reliably (same as list_files):

            get_kb      GET /knowledgeBases/{kbKey}     (kb_key,     hex)
            get_volume  GET /volumes/{volumeKey}        (volume_key, catalog.schema.volume)

        Prefer these over the filtered list_* ops when you already have the
        resource's key — they don't depend on getting catalogKey right.
        """
        from urllib.parse import quote

        if op == "get_kb":
            key = (runtime_params.get("kb_key") or get_cfg(conf, "kb_key", "")).strip()
            key_name, resource = "kb_key", "knowledgeBases"
        else:  # get_volume
            key = (runtime_params.get("volume_key")
                   or get_cfg(conf, "volume_key", "")).strip()
            key_name, resource = "volume_key", "volumes"
        if not key:
            return fail(f"{key_name} is required for {op}.", "ValidationError")

        lake = (runtime_params.get("data_lake_ocid")
                or get_cfg(conf, "data_lake_ocid", "")).strip()
        api_version = str(get_cfg(conf, "api_version", "20260430")).strip()
        service_path = str(get_cfg(conf, "service_path", "aiDataPlatforms")).strip()
        url = (f"https://aidp.{region.strip()}.oci.oraclecloud.com/"
               f"{api_version}/{service_path}/{lake}/{resource}/"
               f"{quote(key, safe='')}")
        debug(f"GET {url}")

        try:
            r = requests.get(url, auth=signer, timeout=timeout,
                             headers={"Accept": "application/json"})
            r.raise_for_status()
        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else "?"
            body = e.response.text[:300] if e.response is not None else ""
            hint = (f" — confirm {key_name} is the exact `key` for this "
                    f"resource.") if status == 404 else ""
            return fail(f"HTTP {status} from {url}: {body}{hint}", "HTTPError",
                        redacted_credential=meta)

        obj = r.json()
        return ok({
            "operation": op,
            "url": url,
            "resource": {
                "key": obj.get("key"),
                "displayName": obj.get("displayName"),
                "description": obj.get("description"),
                "lifecycleState": obj.get("lifecycleState"),
                "catalogKey": obj.get("catalogKey"),
                "schemaKey": obj.get("schemaKey"),
            },
            "redacted_credential": meta,
        })
